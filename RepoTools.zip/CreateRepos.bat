@echo off
setlocal EnableDelayedExpansion
REM ------------------------------------------------------------------
REM  create-repos.bat
REM  Reads RepoDirectory.csv (FolderName,RepoName,Pull,Add-Commit-Push)
REM  and creates any GitHub repo in RepoName that doesn't exist yet,
REM  linking it to the local folder and pushing what's there.
REM
REM  Needs: git and GitHub CLI (gh), logged in via "gh auth login".
REM  Run from the folder that holds the CSV and the repo folders.
REM  Usage:  create-repos.bat [public]     (default is private)
REM ------------------------------------------------------------------

set "CSV=%~dp0RepoDirectory.csv"
set "ROOT=%~dp0"
set "VIS=--private"
if /i "%~1"=="public" set "VIS=--public"

where gh >nul 2>&1 || (echo [ERROR] GitHub CLI ^(gh^) not found. & exit /b 1)
gh auth status >nul 2>&1 || (echo [ERROR] Not logged in. Run: gh auth login & exit /b 1)
if not exist "%CSV%" (echo [ERROR] %CSV% not found. & exit /b 1)

for /f "usebackq skip=1 tokens=1-4 delims=," %%A in ("%CSV%") do (
    set "FOLDER=%%A"
    set "URL=%%B"
    set "SLUG=!URL:https://github.com/=!"
    set "SLUG=!SLUG:.git=!"
    echo.
    echo === !FOLDER!  -^>  !SLUG!

    gh repo view "!SLUG!" >nul 2>&1
    if !errorlevel! equ 0 (
        echo     Repo already exists on GitHub - skipping.
    ) else (
        call :create "!FOLDER!" "!SLUG!"
    )
)

echo.
echo Done.
pause
exit /b 0

:create
set "F=%~1"
set "S=%~2"
pushd "%ROOT%" >nul
if not exist "%F%\" (
    echo     Creating local folder %F%
    mkdir "%F%"
)
cd /d "%ROOT%%F%"

if not exist ".git\" (
    git init -b main >nul
)

REM Make sure there is at least one commit
git rev-parse --verify HEAD >nul 2>&1
if errorlevel 1 (
    if not exist "README.md" echo # %F%> README.md
    git add -A
    git commit -m "Initial commit" >nul
)

git remote get-url origin >nul 2>&1
if errorlevel 1 (
    gh repo create "%S%" %VIS% --source=. --remote=origin --push
) else (
    echo     Local repo already has an origin - creating on GitHub and pushing to it.
    gh repo create "%S%" %VIS%
    git push -u origin HEAD
)
if errorlevel 1 (echo     [FAILED] %S%) else (echo     [OK] https://github.com/%S%)
popd >nul
exit /b 0
